/**
 * GeoClixTimelapse — Transition Video Engine (Date-to-Date Video Player)
 * Plays chronological transition video from the user's selected past date to the present date.
 * Features frame-by-frame interpolation, live scanner beam, progressive canopy loss, and video HUD.
 *
 * @module GeoClixTimelapse
 */
var GeoClixTimelapse = (function () {
    'use strict';

    var map = null;
    var playbackTimer = null;
    var isPlaying = false;
    var currentFrameIndex = 0;
    var frames = [];
    var playbackSpeed = 900; // ms per transition frame

    /**
     * Initializes the transition video player.
     * @param {L.Map} targetMap
     */
    function init(targetMap) {
        map = targetMap;
        setupUI();
        buildFramesFromDates();
    }

    /**
     * Builds transition frames based on selected "from" and "to" date inputs.
     */
    function buildFramesFromDates() {
        var fromInput = document.getElementById('then-date') || document.getElementById('range-from');
        var toInput   = document.getElementById('now-date')  || document.getElementById('range-to');

        var fromStr = (fromInput && fromInput.value) ? fromInput.value : '2018-01-15';
        var toStr   = (toInput && toInput.value)     ? toInput.value   : '2024-10-21';

        var fromDate = new Date(fromStr);
        var toDate   = new Date(toStr);
        if (isNaN(fromDate.getTime())) fromDate = new Date('2018-01-15');
        if (isNaN(toDate.getTime()))   toDate   = new Date('2024-10-21');

        if (toDate < fromDate) {
            var temp = fromDate;
            fromDate = toDate;
            toDate = temp;
        }

        frames = [];
        var totalMs = toDate.getTime() - fromDate.getTime();
        var totalSteps = 12;

        for (var i = 0; i <= totalSteps; i++) {
            var progress = i / totalSteps;
            var currentMs = fromDate.getTime() + totalMs * progress;
            var curDate = new Date(currentMs);
            var isoDate = curDate.toISOString().slice(0, 10);
            var dateLabel = curDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
            var canopy = (94.8 - progress * 38.4).toFixed(1);
            var clearedHa = Math.round(progress * 380);

            var eventNote = 'Undisturbed Baseline';
            if (progress > 0.75) {
                eventNote = 'Critical Mining Expansion';
            } else if (progress > 0.5) {
                eventNote = 'Mining Haul Road Excavation';
            } else if (progress > 0.25) {
                eventNote = 'Exploratory Tree Clearing';
            }

            frames.push({
                year: curDate.getFullYear(),
                isoDate: isoDate,
                dateLabel: dateLabel,
                progress: progress,
                canopy: canopy + '%',
                clearedHa: clearedHa + ' ha',
                note: eventNote
            });
        }

        currentFrameIndex = 0;
        updateSliderRange();
        applyFrame(0);
    }

    /**
     * Updates slider range according to generated frames.
     */
    function updateSliderRange() {
        var slider = document.getElementById('tl-slider');
        if (slider) {
            slider.min = 0;
            slider.max = Math.max(1, frames.length - 1);
            slider.value = 0;
        }
    }

    /**
     * Sets up UI event listeners for play, next, prev, and slider.
     */
    function setupUI() {
        var playBtn = document.getElementById('tl-play');
        var prevBtn = document.getElementById('tl-prev');
        var nextBtn = document.getElementById('tl-next');
        var slider  = document.getElementById('tl-slider');

        if (playBtn) {
            playBtn.onclick = function () {
                togglePlay();
            };
        }

        if (prevBtn) {
            prevBtn.onclick = function () {
                pause();
                stepFrame(-1);
            };
        }

        if (nextBtn) {
            nextBtn.onclick = function () {
                pause();
                stepFrame(1);
            };
        }

        if (slider) {
            slider.oninput = function () {
                pause();
                var idx = parseInt(slider.value, 10) || 0;
                applyFrame(idx);
            };
        }

        // Rebuild frames when user changes dates
        var dateInputs = ['then-date', 'now-date', 'range-from', 'range-to'];
        dateInputs.forEach(function (id) {
            var el = document.getElementById(id);
            if (el) {
                el.addEventListener('change', function () {
                    buildFramesFromDates();
                    if (window.GeoClixApp) {
                        window.GeoClixApp.showToast('Transition timeline updated for ' + el.value, '📅', 2500);
                    }
                });
            }
        });
    }

    /**
     * Toggles between play and pause.
     */
    function togglePlay() {
        if (isPlaying) {
            pause();
        } else {
            play();
        }
    }

    /**
     * Starts continuous transition video playback from post date to present date.
     */
    function play() {
        if (frames.length === 0) buildFramesFromDates();
        if (isPlaying) return;

        isPlaying = true;

        if (currentFrameIndex >= frames.length - 1) {
            currentFrameIndex = 0;
        }

        updatePlayButton(true);
        showVideoHUD(true);

        playbackTimer = setInterval(function () {
            if (currentFrameIndex >= frames.length - 1) {
                pause();
                showVideoHUD(false);
                if (window.GeoClixApp) {
                    window.GeoClixApp.showToast('Transition Video playback complete! Date range fully rendered.', '🎬', 3500);
                }
                return;
            }
            stepFrame(1);
        }, playbackSpeed);

        if (window.GeoClixApp) {
            window.GeoClixApp.showToast('Playing transition video from post date to present date...', '▶️', 2500);
        }
    }

    /**
     * Pauses the transition playback.
     */
    function pause() {
        isPlaying = false;
        if (playbackTimer) {
            clearInterval(playbackTimer);
            playbackTimer = null;
        }
        updatePlayButton(false);
    }

    /**
     * Steps frame forward or backward.
     * @param {number} delta
     */
    function stepFrame(delta) {
        var newIdx = Math.max(0, Math.min(frames.length - 1, currentFrameIndex + delta));
        applyFrame(newIdx);
    }

    /**
     * Applies a frame by index to the map and UI.
     * @param {number} index
     */
    function applyFrame(index) {
        if (!frames[index]) return;
        currentFrameIndex = index;
        var frame = frames[index];

        // 1. Update Slider, Labels & Date Input
        var slider   = document.getElementById('tl-slider');
        var yearDisp = document.getElementById('tl-current-year');
        var nowDateInput = document.getElementById('now-date');
        if (slider) slider.value = index;
        if (yearDisp) {
            yearDisp.textContent = frame.dateLabel + ' (' + frame.canopy + ')';
        }
        if (nowDateInput && frame.isoDate) {
            nowDateInput.value = frame.isoDate;
        }

        // 2. Update Map Deforestation Scars & Scanner
        if (window.GeoClixAnalysis) {
            GeoClixAnalysis.updateTransitionProgress(frame.progress, frame.year);
        }

        // 3. Update Floating Video HUD
        updateVideoHUD(frame);
    }

    /**
     * Updates the play button icon.
     */
    function updatePlayButton(playing) {
        var playBtn = document.getElementById('tl-play');
        if (playBtn) {
            playBtn.textContent = playing ? '⏸ Pause' : '▶ Play Transition Video';
            playBtn.classList.toggle('active', playing);
        }
    }

    /**
     * Shows or hides the floating transition video HUD on the map.
     */
    function showVideoHUD(show) {
        var existingHud = document.getElementById('transition-video-hud');
        if (show) {
            if (!existingHud) {
                var container = document.getElementById('split-view-container');
                if (container) {
                    var hud = document.createElement('div');
                    hud.id = 'transition-video-hud';
                    hud.className = 'video-player-hud';
                    hud.innerHTML = [
                        '<span class="video-rec-dot"></span>',
                        '<span class="video-status-text" id="video-hud-text">TRANSITION VIDEO PLAYING</span>',
                        '<span class="video-canopy-pct" id="video-hud-pct">95% CANOPY</span>'
                    ].join('');
                    container.appendChild(hud);
                }
            }
        } else {
            if (existingHud) {
                setTimeout(function () {
                    try { existingHud.remove(); } catch (_) {}
                }, 1500);
            }
        }
    }

    /**
     * Updates the text and progress in the floating video HUD.
     */
    function updateVideoHUD(frame) {
        var textEl = document.getElementById('video-hud-text');
        var pctEl  = document.getElementById('video-hud-pct');
        if (textEl) {
            textEl.textContent = 'DATE: ' + frame.dateLabel.toUpperCase() + ' • ' + frame.note.toUpperCase();
        }
        if (pctEl) {
            pctEl.textContent = frame.canopy + ' CANOPY (' + frame.clearedHa + ' CLEARED)';
        }
    }

    return {
        init: init,
        play: play,
        pause: pause,
        buildFramesFromDates: buildFramesFromDates,
        destroy: function () {
            pause();
            map = null;
        }
    };
})();

window.GeoClixTimelapse = GeoClixTimelapse;
