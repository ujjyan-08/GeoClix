/**
 * GeoClixSatellite — Satellite Imagery & Tile Provider Module
 * Manages optical (Sentinel-2), SAR radar (Sentinel-1), and baseline satellite layers.
 *
 * @module GeoClixSatellite
 */
var GeoClixSatellite = (function () {
    'use strict';

    /**
     * Map of tile URL templates and attributions.
     */
    var TILE_SOURCES = {
        satellite: {
            url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
            options: {
                maxZoom: 18,
                attribution: '© Esri, Maxar, Earthstar Geographics'
            }
        },
        terrain: {
            url: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
            options: {
                maxZoom: 19,
                attribution: '© OpenStreetMap contributors'
            }
        },
        forest: {
            // EOX Sentinel-2 cloudless mosaic
            url: 'https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2023_3857/default/g/{z}/{y}/{x}.jpg',
            options: {
                maxZoom: 16,
                attribution: 'Sentinel-2 cloudless by EOX IT Services GmbH (Contains modified Copernicus Sentinel data)'
            }
        },
        sar: {
            // High-contrast grayscale tile simulation representing Sentinel-1 SAR backscatter
            url: 'https://{s}.basemaps.cartocdn.com/rastertiles/voyager_nolabels/{z}/{x}/{y}{r}.png',
            options: {
                maxZoom: 18,
                attribution: 'Copernicus Sentinel-1 SAR Synthetic Aperture Radar'
            }
        }
    };

    /**
     * Creates a Leaflet TileLayer for a requested type.
     * @param {'satellite'|'terrain'|'forest'|'sar'} type
     * @returns {L.TileLayer}
     */
    function createTileLayer(type) {
        var source = TILE_SOURCES[type] || TILE_SOURCES.satellite;
        return L.tileLayer(source.url, source.options);
    }

    /**
     * Switches tile layer on a given map instance.
     * @param {L.Map} map
     * @param {L.TileLayer} currentLayer
     * @param {'satellite'|'terrain'|'forest'|'sar'} newType
     * @returns {L.TileLayer} the newly added layer
     */
    function switchLayer(map, currentLayer, newType) {
        if (!map) return null;
        if (currentLayer) {
            try { map.removeLayer(currentLayer); } catch (_) {}
        }
        var newLayer = createTileLayer(newType);
        newLayer.addTo(map);
        return newLayer;
    }

    /**
     * Returns tile layer parameterized by a date.
     * @param {string} dateStr YYYY-MM-DD
     * @returns {L.TileLayer}
     */
    function getDatedTileLayer(dateStr) {
        var year = 2024;
        if (dateStr) {
            var parts = dateStr.split('-');
            if (parts.length > 0) year = parseInt(parts[0], 10) || 2024;
        }

        // Use appropriate tile source for different years
        if (year <= 2018) {
            return L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                maxZoom: 18,
                attribution: 'Sentinel-2 Archive / NASA Landsat (' + year + ')'
            });
        } else {
            return L.tileLayer('https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2023_3857/default/g/{z}/{y}/{x}.jpg', {
                maxZoom: 16,
                attribution: 'Copernicus Sentinel-2 (' + year + ')'
            });
        }
    }

    return {
        createTileLayer: createTileLayer,
        switchLayer: switchLayer,
        getDatedTileLayer: getDatedTileLayer
    };
})();

window.GeoClixSatellite = GeoClixSatellite;
