/**
 * GeoClixAnalysis — Split-View Comparison & Analysis Overlay Module
 * Manages the "Then vs Now" synchronized split-view maps, real satellite clouds,
 * visible deforestation scars, and date-to-date transition video rendering.
 *
 * @module GeoClixAnalysis
 */
var GeoClixAnalysis = (function () {
    'use strict';

    /** @type {L.Map|null} */
    var thenMap = null;
    /** @type {L.Map|null} */
    var nowMap  = null;

    /** @type {L.TileLayer|null} */
    var thenTileLayer = null;
    /** @type {L.TileLayer|null} */
    var nowTileLayer  = null;

    /** @type {L.LayerGroup|null} Pristine canopy layer on Then map */
    var thenCanopyLayer = null;
    /** @type {L.LayerGroup|null} Deforestation scar layer on Now map */
    var nowScarLayer = null;

    /* ── Seamless Atmospheric Cloud Engine (No Map Cuts / Satellite Remains 100% Intact) ── */
    var cloudCanvas = null;
    var cloudCtx = null;
    var cloudAnimId = null;
    var cloudPuffs = [];
    var cloudsEnabled = false;
    var windShiftX = 0;
    var windShiftY = 0;

    var currentLat = 29.5937;
    var currentLng = 78.9629;

    var _syncing = false;
    var _cleanupFns = [];

    /**
     * Gets genuine Sentinel-2 satellite tile layer for a specific date/year.
     * Uses real EOX Sentinel-2 yearly cloudless mosaics (2018-2023) and high-res present imagery.
     * @param {string} dateStr 'YYYY-MM-DD'
     * @returns {L.TileLayer}
     */
    function getTileLayerForDate(dateStr) {
        var year = 2024;
        if (dateStr) {
            year = parseInt(dateStr.slice(0, 4), 10) || 2024;
        }

        if (year <= 2018) {
            return L.tileLayer('https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2018_3857/default/g/{z}/{y}/{x}.jpg', {
                maxZoom: 18,
                maxNativeZoom: 15,
                attribution: '© Copernicus Sentinel-2 (2018 Baseline Archive) by EOX'
            });
        } else if (year === 2019) {
            return L.tileLayer('https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2019_3857/default/g/{z}/{y}/{x}.jpg', {
                maxZoom: 18,
                maxNativeZoom: 15,
                attribution: '© Copernicus Sentinel-2 (2019 Archive) by EOX'
            });
        } else if (year === 2020) {
            return L.tileLayer('https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2020_3857/default/g/{z}/{y}/{x}.jpg', {
                maxZoom: 18,
                maxNativeZoom: 15,
                attribution: '© Copernicus Sentinel-2 (2020 Archive) by EOX'
            });
        } else if (year === 2021) {
            return L.tileLayer('https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2021_3857/default/g/{z}/{y}/{x}.jpg', {
                maxZoom: 18,
                maxNativeZoom: 15,
                attribution: '© Copernicus Sentinel-2 (2021 Archive) by EOX'
            });
        } else if (year === 2022) {
            return L.tileLayer('https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2022_3857/default/g/{z}/{y}/{x}.jpg', {
                maxZoom: 18,
                maxNativeZoom: 15,
                attribution: '© Copernicus Sentinel-2 (2022 Archive) by EOX'
            });
        } else if (year === 2023) {
            return L.tileLayer('https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2023_3857/default/g/{z}/{y}/{x}.jpg', {
                maxZoom: 18,
                maxNativeZoom: 15,
                attribution: '© Copernicus Sentinel-2 (2023 Cloudless) by EOX'
            });
        } else {
            return L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                maxZoom: 18,
                attribution: '© Copernicus Sentinel-2 (2024 Present High-Res Mosaic)'
            });
        }
    }

    /**
     * Applies visual color grading to differentiate Then (healthy) vs Now (degraded).
     * The Then map gets a lush green tint; the Now map gets a warm brown/degraded tint.
     */
    function applyMapColorGrading() {
        if (thenMap) {
            // Lush green, high saturation — healthy undisturbed forest look
            thenMap.getContainer().style.filter = 'saturate(1.45) brightness(1.05) hue-rotate(-8deg)';
        }
        if (nowMap) {
            // Warmer, desaturated, slightly brown — disturbed/degraded look
            nowMap.getContainer().style.filter = 'saturate(0.7) brightness(0.92) sepia(0.2) contrast(1.1)';
        }
    }

    /**
     * Initializes both "Then" and "Now" Leaflet maps with date-specific satellite imagery.
     * @param {number} lat
     * @param {number} lng
     */
    function init(lat, lng) {
        try {
            destroy();

            currentLat = lat || 29.5937;
            currentLng = lng || 78.9629;
            var center = [currentLat, currentLng];
            var zoom = 13;

            var fromInput = document.getElementById('then-date') || document.getElementById('range-from');
            var toInput   = document.getElementById('now-date')  || document.getElementById('range-to');
            var thenDateVal = (fromInput && fromInput.value) ? fromInput.value : '2018-01-15';
            var nowDateVal  = (toInput && toInput.value)     ? toInput.value   : '2024-10-21';

            // ── 1. THEN MAP (Historical Baseline Satellite Imagery) ──
            thenMap = L.map('then-map', {
                center: center,
                zoom: zoom,
                zoomControl: false,
                attributionControl: false
            });

            thenTileLayer = getTileLayerForDate(thenDateVal).addTo(thenMap);
            thenCanopyLayer = L.layerGroup().addTo(thenMap);
            renderPristineCanopy(currentLat, currentLng);

            // ── 2. NOW MAP (Present / Alert Detected Satellite Imagery) ──
            nowMap = L.map('now-map', {
                center: center,
                zoom: zoom,
                zoomControl: false,
                attributionControl: false
            });

            nowTileLayer = getTileLayerForDate(nowDateVal).addTo(nowMap);
            nowScarLayer = L.layerGroup().addTo(nowMap);

            // ── 3. Synchronize movement ──
            syncMaps(thenMap, nowMap);

            // ── 3b. Visual color grading so Past (green/healthy) looks different from Present (degraded/brown) ──
            applyMapColorGrading();

            // ── 4. Setup Controls & Date Sync ──
            setupSplitDivider();
            setupOverlayToggles();
            setupDateInputs();

            // Initial synchronization of imagery & pill labels
            updateDateImagery();

            // Update coordinate displays
            var latEl = document.getElementById('detail-lat');
            var lngEl = document.getElementById('detail-lng');
            if (latEl && window.GeoClixCoordinates) latEl.textContent = GeoClixCoordinates.formatCoord(currentLat, 'lat');
            if (lngEl && window.GeoClixCoordinates) lngEl.textContent = GeoClixCoordinates.formatCoord(currentLng, 'lng');

            // Multi-pass map invalidation so tiles load instantly without blank/gray sections
            requestAnimationFrame(function () {
                if (thenMap) thenMap.invalidateSize();
                if (nowMap)  nowMap.invalidateSize();
            });
            setTimeout(function () {
                if (thenMap) thenMap.invalidateSize();
                if (nowMap)  nowMap.invalidateSize();
            }, 100);
            setTimeout(function () {
                if (thenMap) thenMap.invalidateSize();
                if (nowMap)  nowMap.invalidateSize();
            }, 300);
            setTimeout(function () {
                if (thenMap) thenMap.invalidateSize();
                if (nowMap)  nowMap.invalidateSize();
            }, 600);

            console.info('[GeoClixAnalysis] Initialised at', currentLat, currentLng);
        } catch (e) {
            console.warn('[GeoClixAnalysis] init error:', e);
        }
    }

    /**
     * Renders healthy green canopy overlay on "Then" map — large, lush, undisturbed forest.
     * @param {number} lat
     * @param {number} lng
     * @param {number} [factor=1.0] (Relative health factor)
     */
    function renderPristineCanopy(lat, lng, factor) {
        if (!thenCanopyLayer) return;
        thenCanopyLayer.clearLayers();

        if (factor === undefined) factor = 1.0;
        if (factor <= 0.05) return;

        var delta = 0.065;

        // 1. Large undisturbed dense canopy polygon
        var pristinePolygon = L.polygon([
            [lat - delta, lng - delta * 1.2],
            [lat + delta * 1.1, lng - delta * 0.9],
            [lat + delta * 1.2, lng + delta * 1.1],
            [lat - delta * 0.7, lng + delta * 1.2],
            [lat - delta * 1.1, lng + delta * 0.3]
        ], {
            color: '#16a34a',
            fillColor: '#15803d',
            fillOpacity: 0.35 * factor,
            weight: 2
        }).bindPopup(
            '<div style="font-family:var(--font-heading);">' +
            '<span style="color:#22c55e;font-weight:700;">🌿 UNDISTURBED PRISTINE CANOPY</span><br>' +
            '<b>NDVI:</b> 0.84 (Very Dense Forest)<br>' +
            '<b>Canopy Cover:</b> ' + (94.8 * factor).toFixed(1) + '%<br>' +
            '<b>Species:</b> Sal, Teak, Bamboo, Mixed Deciduous<br>' +
            '<b>Carbon Sequestration:</b> Active (≈42 t/ha/yr)' +
            '</div>'
        );

        // 2. Secondary dense patches around main canopy
        var patches = [
            { dlat: -0.04, dlng: 0.05, s: 0.025 },
            { dlat: 0.05, dlng: -0.04, s: 0.03 },
            { dlat: -0.02, dlng: -0.06, s: 0.022 },
            { dlat: 0.06, dlng: 0.03, s: 0.028 }
        ];

        thenCanopyLayer.addLayer(pristinePolygon);

        patches.forEach(function (p) {
            var circle = L.circle([lat + p.dlat, lng + p.dlng], {
                radius: p.s * 111000,
                color: '#22c55e',
                fillColor: '#166534',
                fillOpacity: 0.3 * factor,
                weight: 1
            });
            thenCanopyLayer.addLayer(circle);
        });

        // 3. "Healthy corridor" polyline showing intact wildlife connectivity
        var corridor = L.polyline([
            [lat - delta * 0.8, lng - delta],
            [lat - delta * 0.2, lng - delta * 0.5],
            [lat + delta * 0.4, lng + delta * 0.2],
            [lat + delta * 0.9, lng + delta * 0.8]
        ], {
            color: '#4ade80',
            weight: 3,
            opacity: 0.7 * factor,
            dashArray: '8 5'
        }).bindPopup('<b>Intact Wildlife Corridor</b> — Unbroken canopy connectivity');
        thenCanopyLayer.addLayer(corridor);
    }

    /**
     * Renders striking, highly visible deforestation scar patterns on "Now" map.
     * Deliberately large and dramatic so the difference from the "Then" map is unmistakable.
     * @param {number} lat
     * @param {number} lng
     * @param {number} progress (0.0 = pristine to 1.0 = full deforestation)
     */
    function renderDeforestationScars(lat, lng, progress) {
        if (!nowScarLayer) return;
        nowScarLayer.clearLayers();

        if (progress <= 0.04) return; // Before clearing began

        var delta = 0.06 * progress;

        // 1. Main excavated open-cast mine pit — large bare earth polygon
        var bareEarthPolygon = L.polygon([
            [lat - delta * 0.5, lng - delta * 0.6],
            [lat + delta * 0.3, lng - delta * 0.8],
            [lat + delta * 0.8, lng - delta * 0.3],
            [lat + delta * 0.9, lng + delta * 0.6],
            [lat + delta * 0.3, lng + delta * 0.9],
            [lat - delta * 0.4, lng + delta * 0.7],
            [lat - delta * 0.7, lng + delta * 0.1]
        ], {
            color: '#92400e',
            weight: 2,
            fillColor: '#78350f',
            fillOpacity: 0.75 * Math.min(1, progress * 1.2),
            dashArray: '4 2'
        }).bindPopup(
            '<div style="font-family:var(--font-heading);">' +
            '<b style="color:#ef4444;">⛏️ OPEN-CAST MINE EXCAVATION</b><br>' +
            'Exposed bedrock & mineral soil<br>' +
            '<b>Area:</b> ' + (3.4 * progress).toFixed(1) + ' km²' +
            '</div>'
        );

        // 2. Red alert boundary perimeter (wider than the bare earth)
        var alertBoundary = L.polygon([
            [lat - delta * 0.65, lng - delta * 0.75],
            [lat + delta * 0.4, lng - delta * 0.95],
            [lat + delta * 0.95, lng - delta * 0.4],
            [lat + delta * 1.05, lng + delta * 0.75],
            [lat + delta * 0.4, lng + delta * 1.05],
            [lat - delta * 0.55, lng + delta * 0.85],
            [lat - delta * 0.85, lng + delta * 0.15]
        ], {
            color: '#ef4444',
            weight: 3,
            fillColor: '#ef4444',
            fillOpacity: 0.18 * Math.min(1, progress * 1.1),
            className: 'deforestation-scar-polygon'
        }).bindPopup(
            '<div style="font-family:var(--font-heading);">' +
            '  <span style="color:#ef4444;font-weight:700;">⚠️ ACTIVE DEFORESTATION DETECTED</span><br>' +
            '  <b>Cleared Area:</b> ' + (3.4 * progress).toFixed(1) + ' km²<br>' +
            '  <b>Primary Loss Driver:</b> Open-Cast Mining & Road Cut<br>' +
            '  <b>Sensor Agreement:</b> Sentinel-2 + Sentinel-1 SAR (100%)' +
            '</div>'
        );

        // 3. Secondary smaller clear-cut patch
        var secondaryCut = L.polygon([
            [lat + delta * 0.6, lng + delta * 1.1],
            [lat + delta * 0.9, lng + delta * 1.3],
            [lat + delta * 1.2, lng + delta * 1.15],
            [lat + delta * 1.1, lng + delta * 0.85]
        ], {
            color: '#a16207',
            weight: 1.5,
            fillColor: '#a16207',
            fillOpacity: 0.55 * progress
        }).bindPopup('<b>Secondary Clearing:</b> Timber staging area and log yard');

        // 4. Linear road clearance cuts — multiple haul roads
        var mainRoad = L.polyline([
            [lat - delta * 1.4, lng - delta * 1.4],
            [lat - delta * 0.5, lng - delta * 0.6],
            [lat + delta * 0.3, lng + delta * 0.1],
            [lat + delta * 0.9, lng + delta * 0.6],
            [lat + delta * 1.5, lng + delta * 1.5]
        ], {
            color: '#d97706',
            weight: 5,
            opacity: 0.85 * progress,
            dashArray: '8 4'
        }).bindPopup('<b>Primary Haul Road:</b> 40m corridor cut for mining access');

        var branchRoad = L.polyline([
            [lat + delta * 0.3, lng + delta * 0.1],
            [lat + delta * 0.5, lng - delta * 0.6],
            [lat + delta * 0.8, lng - delta * 1.0]
        ], {
            color: '#b45309',
            weight: 3.5,
            opacity: 0.7 * progress,
            dashArray: '5 3'
        }).bindPopup('<b>Branch Access Road:</b> Secondary logging access corridor');

        // 5. Degraded buffer zone — canopy thinning perimeter
        var degradedBuffer = L.circle([lat, lng], {
            radius: delta * 111000 * 1.6,
            color: '#facc15',
            weight: 1.5,
            fillColor: '#eab308',
            fillOpacity: 0.12 * progress,
            dashArray: '6 4'
        }).bindPopup('<b>Degraded Buffer Zone:</b> Canopy thinning from dust, runoff & edge effects');

        nowScarLayer.addLayer(degradedBuffer);
        nowScarLayer.addLayer(bareEarthPolygon);
        nowScarLayer.addLayer(alertBoundary);
        nowScarLayer.addLayer(secondaryCut);
        nowScarLayer.addLayer(mainRoad);
        nowScarLayer.addLayer(branchRoad);

        // 6. Thermal fire hotspots
        if (progress > 0.3) {
            var fires = [
                { dlat: delta * 0.35, dlng: delta * 0.25, r: 12 },
                { dlat: -delta * 0.2, dlng: delta * 0.5, r: 9 },
                { dlat: delta * 0.7, dlng: -delta * 0.1, r: 10 }
            ];
            fires.forEach(function (f) {
                if (Math.random() < progress) {
                    var hotspot = L.circleMarker([lat + f.dlat, lng + f.dlng], {
                        radius: f.r,
                        color: '#ea580c',
                        weight: 2,
                        fillColor: '#f97316',
                        fillOpacity: 0.9
                    }).bindPopup('<b>NASA FIRMS Thermal Hotspot:</b> Active Slash & Burn Detected');
                    nowScarLayer.addLayer(hotspot);
                }
            });
        }

        // 7. Pulsing "ALERT" circle marker at center
        var alertCenter = L.circleMarker([lat, lng], {
            radius: 8,
            color: '#ef4444',
            weight: 3,
            fillColor: '#dc2626',
            fillOpacity: 0.9,
            className: 'pulse-alert-marker'
        }).bindPopup('<b style="color:#ef4444;">⚠️ DEFORESTATION EPICENTER</b><br>3.4 km² active clearing zone');
        nowScarLayer.addLayer(alertCenter);
    }

    /**
     * Updates deforestation extent during video transition playback.
     * @param {number} progress (0.0 to 1.0)
     * @param {number} year
     */
    function updateTransitionProgress(progress, year) {
        renderDeforestationScars(currentLat, currentLng, progress);

        // Update tile layer during video playback if year changes
        if (nowMap && year) {
            var targetTileLayer = getTileLayerForDate(year + '-06-01');
            if (nowTileLayer && nowTileLayer._url !== targetTileLayer._url) {
                try { nowMap.removeLayer(nowTileLayer); } catch (_) {}
                nowTileLayer = targetTileLayer.addTo(nowMap);
            }
        }

        // Update now pill tag during video
        var nowPill = document.getElementById('now-pill-tag');
        if (nowPill) {
            var clearedKm = (3.4 * progress).toFixed(1);
            var remainingCanopy = (94.8 - progress * 38.4).toFixed(1);
            nowPill.innerHTML = '⚠️ Transition (' + year + '): -' + clearedKm + ' km² Cleared • ' + remainingCanopy + '% Canopy';
        }

        // Subtle scanner beam sweep
        var scanLine = document.getElementById('transition-scan-line');
        if (!scanLine) {
            var container = document.getElementById('now-pane');
            if (container) {
                scanLine = document.createElement('div');
                scanLine.id = 'transition-scan-line';
                scanLine.className = 'transition-scan-line';
                container.appendChild(scanLine);
            }
        }
        if (scanLine) {
            scanLine.style.left = (progress * 100) + '%';
        }
    }

    /**
     * Sets up instant, real-time bidirectional pan/zoom sync between Then and Now maps.
     */
    function syncMaps(map1, map2) {
        var isSyncing = false;

        function onMove1() {
            if (isSyncing || !map2) return;
            isSyncing = true;
            map2.setView(map1.getCenter(), map1.getZoom(), { animate: false });
            isSyncing = false;
        }

        function onMove2() {
            if (isSyncing || !map1) return;
            isSyncing = true;
            map1.setView(map2.getCenter(), map2.getZoom(), { animate: false });
            isSyncing = false;
        }

        map1.on('move', onMove1);
        map2.on('move', onMove2);
        map1.on('zoom', onMove1);
        map2.on('zoom', onMove2);

        _cleanupFns.push(function () {
            try {
                map1.off('move', onMove1);
                map2.off('move', onMove2);
                map1.off('zoom', onMove1);
                map2.off('zoom', onMove2);
            } catch (_) {}
        });
    }

    /**
     * Sets up the silky smooth draggable split divider.
     */
    function setupSplitDivider() {
        var container = document.getElementById('split-view-container');
        var divider   = document.getElementById('split-divider');
        var thenPane  = document.getElementById('then-pane');
        var nowPane   = document.getElementById('now-pane');

        if (!container || !divider || !thenPane || !nowPane) return;

        var isDragging = false;
        var rafPending = false;
        var pendingX = 0;

        function updateDivider() {
            rafPending = false;
            var rect = container.getBoundingClientRect();
            var offset = pendingX - rect.left;
            var pct = Math.max(8, Math.min(92, (offset / rect.width) * 100));

            divider.style.left = pct + '%';
            thenPane.style.width = pct + '%';
            nowPane.style.width  = (100 - pct) + '%';

            if (thenMap) thenMap.invalidateSize({ pan: false });
            if (nowMap)  nowMap.invalidateSize({ pan: false });
        }

        function queuePos(clientX) {
            pendingX = clientX;
            if (!rafPending) {
                rafPending = true;
                requestAnimationFrame(updateDivider);
            }
        }

        function onMouseDown(e) {
            isDragging = true;
            document.body.style.cursor = 'col-resize';
            e.preventDefault();
        }

        function onMouseMove(e) {
            if (!isDragging) return;
            queuePos(e.clientX);
        }

        function onMouseUp() {
            if (isDragging) {
                isDragging = false;
                document.body.style.cursor = '';
                if (thenMap) thenMap.invalidateSize();
                if (nowMap)  nowMap.invalidateSize();
            }
        }

        function onTouchMove(e) {
            if (!isDragging || !e.touches || !e.touches[0]) return;
            queuePos(e.touches[0].clientX);
        }

        divider.addEventListener('mousedown', onMouseDown);
        window.addEventListener('mousemove', onMouseMove);
        window.addEventListener('mouseup', onMouseUp);

        divider.addEventListener('touchstart', function () { isDragging = true; });
        window.addEventListener('touchmove', onTouchMove);
        window.addEventListener('touchend', onMouseUp);

        _cleanupFns.push(function () {
            divider.removeEventListener('mousedown', onMouseDown);
            window.removeEventListener('mousemove', onMouseMove);
            window.removeEventListener('mouseup', onMouseUp);
            window.removeEventListener('touchmove', onTouchMove);
            window.removeEventListener('touchend', onMouseUp);
        });
    }

    /* ── Procedural Atmospheric Cloud System (Seamless, Never Cuts the Satellite Map) ── */
    function initCloudCanvas() {
        var pane = document.getElementById('now-pane');
        if (!pane) return;

        if (!cloudCanvas) {
            cloudCanvas = document.createElement('canvas');
            cloudCanvas.id = 'atmosphere-clouds-canvas';
            cloudCanvas.className = 'atmospheric-clouds-canvas';
            cloudCanvas.style.position = 'absolute';
            cloudCanvas.style.top = '0';
            cloudCanvas.style.left = '0';
            cloudCanvas.style.width = '100%';
            cloudCanvas.style.height = '100%';
            cloudCanvas.style.pointerEvents = 'none';
            cloudCanvas.style.zIndex = '12'; // Above tiles, below HUD controls
            cloudCanvas.style.transition = 'opacity 0.4s ease';
            cloudCanvas.style.opacity = '0';
            pane.appendChild(cloudCanvas);
        }

        cloudCtx = cloudCanvas.getContext('2d');
        syncCloudCanvasSize();
        generateCloudClusters(currentLat, currentLng);
    }

    function syncCloudCanvasSize() {
        if (!cloudCanvas) return;
        var pane = document.getElementById('now-pane');
        if (!pane) return;
        var rect = pane.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0) {
            cloudCanvas.width = rect.width;
            cloudCanvas.height = rect.height;
        }
    }

    function generateCloudClusters(lat, lng) {
        cloudPuffs = [];
        var span = 0.09;
        for (var i = 0; i < 34; i++) {
            var puffLat = lat + Math.sin(i * 1.9 + 0.3) * span * 0.85;
            var puffLng = lng + Math.cos(i * 1.4 + 0.8) * span * 1.25;
            var radius = 45 + ((i * 31) % 55);
            var density = 0.65 + ((i % 5) * 0.07);

            var subPuffs = [];
            for (var j = 0; j < 5; j++) {
                subPuffs.push({
                    dx: Math.sin(j * 2.3 + i) * radius * 0.55,
                    dy: Math.cos(j * 1.7 + i) * radius * 0.45,
                    r: radius * (0.65 + (j % 3) * 0.2)
                });
            }

            cloudPuffs.push({
                lat: puffLat,
                lng: puffLng,
                radius: radius,
                density: density,
                subPuffs: subPuffs
            });
        }
    }

    function renderCloudsLoop() {
        if (!cloudsEnabled || !cloudCanvas || !cloudCtx || !nowMap) return;

        var width = cloudCanvas.width;
        var height = cloudCanvas.height;
        if (width === 0 || height === 0) {
            syncCloudCanvasSize();
            width = cloudCanvas.width;
            height = cloudCanvas.height;
        }

        cloudCtx.clearRect(0, 0, width, height);

        // Wind drift animation
        windShiftX += 0.2;
        windShiftY -= 0.05;
        if (windShiftX > 200) windShiftX = 0;

        var sarActive = document.getElementById('sar-toggle') && document.getElementById('sar-toggle').checked;

        for (var i = 0; i < cloudPuffs.length; i++) {
            var p = cloudPuffs[i];
            var pt = nowMap.latLngToContainerPoint([p.lat, p.lng]);
            var px = pt.x + (windShiftX % 160) - 80;
            var py = pt.y + (windShiftY % 70) - 35;

            // 1. Soft natural cloud shadow on terrain below (Sentinel-2 realism)
            if (!sarActive && px > -120 && px < width + 120 && py > -120 && py < height + 120) {
                var sGrad = cloudCtx.createRadialGradient(px + 16, py + 14, 0, px + 16, py + 14, p.radius * 1.35);
                sGrad.addColorStop(0, 'rgba(10, 16, 12, 0.24)');
                sGrad.addColorStop(0.65, 'rgba(10, 16, 12, 0.1)');
                sGrad.addColorStop(1, 'rgba(10, 16, 12, 0)');
                cloudCtx.fillStyle = sGrad;
                cloudCtx.beginPath();
                cloudCtx.arc(px + 16, py + 14, p.radius * 1.35, 0, Math.PI * 2);
                cloudCtx.fill();
            }

            // 2. Billowy cumulus cloud formation
            if (px > -120 && px < width + 120 && py > -120 && py < height + 120) {
                for (var j = 0; j < p.subPuffs.length; j++) {
                    var sp = p.subPuffs[j];
                    var sx = px + sp.dx;
                    var sy = py + sp.dy;
                    var cGrad = cloudCtx.createRadialGradient(sx, sy, 0, sx, sy, sp.r);

                    if (sarActive) {
                        // Sentinel-1 SAR Radar Penetration Mode
                        cGrad.addColorStop(0, 'rgba(186, 230, 253, 0.22)');
                        cGrad.addColorStop(0.6, 'rgba(147, 197, 253, 0.1)');
                        cGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
                    } else {
                        // Natural Optical Cloud Bank (Sentinel-2 MSI)
                        cGrad.addColorStop(0, 'rgba(255, 255, 255, ' + (p.density * 0.95) + ')');
                        cGrad.addColorStop(0.5, 'rgba(241, 245, 249, ' + (p.density * 0.75) + ')');
                        cGrad.addColorStop(0.85, 'rgba(226, 232, 240, ' + (p.density * 0.35) + ')');
                        cGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
                    }

                    cloudCtx.fillStyle = cGrad;
                    cloudCtx.beginPath();
                    cloudCtx.arc(sx, sy, sp.r, 0, Math.PI * 2);
                    cloudCtx.fill();
                }
            }
        }

        // 3. SAR Active: Microwave Grid Pulse Overlay
        if (sarActive) {
            cloudCtx.strokeStyle = 'rgba(56, 189, 248, 0.15)';
            cloudCtx.lineWidth = 1;
            var step = 45;
            cloudCtx.beginPath();
            for (var x = 0; x < width; x += step) {
                cloudCtx.moveTo(x, 0);
                cloudCtx.lineTo(x, height);
            }
            for (var y = 0; y < height; y += step) {
                cloudCtx.moveTo(0, y);
                cloudCtx.lineTo(width, y);
            }
            cloudCtx.stroke();
        }

        cloudAnimId = requestAnimationFrame(renderCloudsLoop);
    }

    function startClouds() {
        cloudsEnabled = true;
        initCloudCanvas();
        if (cloudCanvas) {
            cloudCanvas.style.opacity = '1';
        }
        if (!cloudAnimId) {
            cloudAnimId = requestAnimationFrame(renderCloudsLoop);
        }
        if (nowMap) {
            nowMap.on('move', syncCloudCanvasSize);
            nowMap.on('zoom', syncCloudCanvasSize);
        }
    }

    function stopClouds() {
        cloudsEnabled = false;
        if (cloudCanvas) {
            cloudCanvas.style.opacity = '0';
        }
        if (cloudAnimId) {
            cancelAnimationFrame(cloudAnimId);
            cloudAnimId = null;
        }
        if (cloudCtx && cloudCanvas) {
            cloudCtx.clearRect(0, 0, cloudCanvas.width, cloudCanvas.height);
        }
    }

    /**
     * Overlay Toggles: Real Atmospheric Clouds, SAR Radar, Deforestation Scars.
     */
    function setupOverlayToggles() {
        // 1. Clouds Toggle (Procedural atmospheric clouds directly over satellite map)
        var cloudsToggle = document.getElementById('clouds-toggle');
        if (cloudsToggle) {
            cloudsToggle.addEventListener('change', function () {
                var pill = cloudsToggle.closest('.overlay-checkbox, .filter-layer-pill');
                if (pill) {
                    if (cloudsToggle.checked) pill.classList.add('active');
                    else pill.classList.remove('active');
                }
                if (cloudsToggle.checked) {
                    startClouds();
                    if (window.GeoClixApp) {
                        window.GeoClixApp.showToast('Atmospheric cloud cover active (Sentinel-2 Optical)', '☁️', 3000);
                    }
                } else {
                    stopClouds();
                }
            });
        }

        // 2. SAR Radar Toggle (Penetrates clouds!)
        var sarToggle = document.getElementById('sar-toggle');
        if (sarToggle) {
            sarToggle.addEventListener('change', function () {
                var pill = sarToggle.closest('.overlay-checkbox, .filter-layer-pill');
                if (pill) {
                    if (sarToggle.checked) pill.classList.add('active');
                    else pill.classList.remove('active');
                }
                if (nowMap) {
                    if (sarToggle.checked) {
                        nowMap.getContainer().style.filter = 'saturate(0.65) brightness(0.95) contrast(1.25) sepia(0.2)';
                        if (window.GeoClixApp) {
                            window.GeoClixApp.showToast('Sentinel-1 SAR Active: Microwave radar penetrates cloud layer', '📡', 3500);
                        }
                    } else {
                        applyMapColorGrading();
                    }
                }
            });
        }

        // 3. Deforestation Scars Toggle
        var scarsToggle = document.getElementById('scars-toggle');
        if (scarsToggle) {
            scarsToggle.addEventListener('change', function () {
                var pill = scarsToggle.closest('.overlay-checkbox, .filter-layer-pill');
                if (pill) {
                    if (scarsToggle.checked) pill.classList.add('active');
                    else pill.classList.remove('active');
                }
                if (scarsToggle.checked) {
                    if (nowScarLayer && nowMap && !nowMap.hasLayer(nowScarLayer)) {
                        nowMap.addLayer(nowScarLayer);
                    }
                } else {
                    if (nowScarLayer && nowMap && nowMap.hasLayer(nowScarLayer)) {
                        nowMap.removeLayer(nowScarLayer);
                    }
                }
            });
        }

        // 4. Date Inputs change event listeners
        var fromInput = document.getElementById('then-date');
        var toInput   = document.getElementById('now-date');
        if (fromInput) {
            fromInput.addEventListener('change', function () {
                updateDateImagery();
            });
        }
        if (toInput) {
            toInput.addEventListener('change', function () {
                updateDateImagery();
            });
        }
    }

    /**
     * Synchronizes both maps and deforestation extent to the exact selected dates.
     * Supports any date range, custom calendar selection, preset triggers, or manual typing.
     */
    function updateDateImagery() {
        var thenInput = document.getElementById('then-date');
        var nowInput  = document.getElementById('now-date');
        var rangeFrom = document.getElementById('range-from');
        var rangeTo   = document.getElementById('range-to');

        // Extract dates with robust defaults
        var thenVal = (thenInput && thenInput.value) ? thenInput.value : (rangeFrom && rangeFrom.value ? rangeFrom.value : '2018-01-15');
        var nowVal  = (nowInput && nowInput.value)   ? nowInput.value   : (rangeTo && rangeTo.value ? rangeTo.value : '2024-10-21');

        // Bidirectionally synchronize all input fields
        if (thenInput && thenInput.value !== thenVal) thenInput.value = thenVal;
        if (rangeFrom && rangeFrom.value !== thenVal) rangeFrom.value = thenVal;
        if (nowInput && nowInput.value !== nowVal)    nowInput.value = nowVal;
        if (rangeTo && rangeTo.value !== nowVal)      rangeTo.value = nowVal;

        var thenDateObj = new Date(thenVal);
        var nowDateObj  = new Date(nowVal);
        if (isNaN(thenDateObj.getTime())) thenDateObj = new Date('2018-01-15');
        if (isNaN(nowDateObj.getTime()))  nowDateObj  = new Date('2024-10-21');

        var thenYear = thenDateObj.getFullYear();
        var nowYear  = nowDateObj.getFullYear();

        // 1. Update Then Tile Layer with that specific baseline date's mosaic
        if (thenMap) {
            if (thenTileLayer) {
                try { thenMap.removeLayer(thenTileLayer); } catch (_) {}
            }
            thenTileLayer = getTileLayerForDate(thenVal).addTo(thenMap);
            if (thenCanopyLayer && thenMap.hasLayer(thenCanopyLayer)) {
                try { thenCanopyLayer.bringToFront(); } catch (_) {}
            }
        }

        // 2. Update Now Tile Layer with that specific present date's imagery
        if (nowMap) {
            if (nowTileLayer) {
                try { nowMap.removeLayer(nowTileLayer); } catch (_) {}
            }
            nowTileLayer = getTileLayerForDate(nowVal).addTo(nowMap);
            if (nowScarLayer && nowMap.hasLayer(nowScarLayer)) {
                try { nowScarLayer.bringToFront(); } catch (_) {}
            }
        }

        // 3. Compute relative deforestation progress between baseline anchor (Jan 2018) and present
        var anchorStart = new Date('2018-01-15').getTime();
        var anchorEnd   = new Date('2024-10-21').getTime();
        var totalSpanMs = Math.max(1, anchorEnd - anchorStart);
        var diffMs      = nowDateObj.getTime() - thenDateObj.getTime();

        var progress = 1.0;
        if (diffMs <= 0) {
            progress = 0.0; // Same date or inverted: baseline matches detected, 0% loss
        } else {
            progress = Math.min(1.0, Math.max(0.04, diffMs / totalSpanMs));
        }

        // 4. Dynamically re-render deforestation scars & pristine canopy
        renderDeforestationScars(currentLat, currentLng, progress);

        if (thenYear <= 2019) {
            renderPristineCanopy(currentLat, currentLng, 1.0);
        } else {
            var baselineDisturbance = Math.min(0.6, (thenYear - 2018) / 6.0);
            renderPristineCanopy(currentLat, currentLng, 1.0 - baselineDisturbance);
        }

        // 5. Dynamic visual color grading reflecting genuine satellite degradation over time
        if (thenMap) {
            thenMap.getContainer().style.filter = 'saturate(1.45) brightness(1.05) hue-rotate(-8deg)';
        }
        if (nowMap) {
            var sarActive = document.getElementById('sar-toggle') && document.getElementById('sar-toggle').checked;
            if (sarActive) {
                nowMap.getContainer().style.filter = 'saturate(0.65) brightness(0.95) contrast(1.25) sepia(0.2)';
            } else {
                var sat = (1.4 - progress * 0.7).toFixed(2);
                var sep = (progress * 0.22).toFixed(2);
                var bri = (1.04 - progress * 0.12).toFixed(2);
                nowMap.getContainer().style.filter = 'saturate(' + sat + ') brightness(' + bri + ') sepia(' + sep + ') contrast(1.1)';
            }
        }

        // 6. Update Pill Tags with selected dates and status
        var thenPill = document.getElementById('then-pill-tag');
        var nowPill  = document.getElementById('now-pill-tag');
        if (thenPill) {
            thenPill.innerHTML = '🌿 Baseline (' + thenVal + '): ' + (thenYear <= 2019 ? '94.8% Pristine Canopy' : 'Baseline Reference') + ' (NDVI: 0.84)';
        }
        if (nowPill) {
            var clearedKm = (3.4 * progress).toFixed(1);
            var remainingCanopy = (94.8 - progress * 38.4).toFixed(1);
            if (progress <= 0.04) {
                nowPill.innerHTML = '🌿 Present (' + nowVal + '): Baseline Reference (0.0 km² Loss)';
            } else {
                nowPill.innerHTML = '⚠️ Present (' + nowVal + '): -' + clearedKm + ' km² Cleared • ' + remainingCanopy + '% Canopy';
            }
        }

        // 7. Update left sidebar canopy intelligence values
        var canopyValEl = document.querySelector('.canopy-intel-val.red-text');
        if (canopyValEl) {
            canopyValEl.textContent = (94.8 - progress * 38.4).toFixed(1) + '%';
        }

        var allIntelVals = document.querySelectorAll('.canopy-intel-val');
        if (allIntelVals.length >= 3) {
            allIntelVals[2].textContent = Math.round(24800 * progress).toLocaleString() + ' t';
        }
        if (allIntelVals.length >= 4) {
            if (progress > 0.7) {
                allIntelVals[3].textContent = 'MINING / ROAD';
            } else if (progress > 0.35) {
                allIntelVals[3].textContent = 'ROAD EXPANSION';
            } else if (progress > 0.05) {
                allIntelVals[3].textContent = 'SURVEY CLEARING';
            } else {
                allIntelVals[3].textContent = 'VIRGIN FOREST';
            }
        }

        // 8. Auto-highlight matching preset buttons
        document.querySelectorAll('.preset-btn, .preset-pill').forEach(function (btn) {
            btn.classList.remove('active');
        });
        if (thenVal === '2018-01-15' && nowVal === '2024-10-21') {
            var p1 = document.querySelector('[onclick*="2018 vs 2024"]');
            if (p1) p1.classList.add('active');
        } else if (thenVal === '2018-01-15' && nowVal === '2021-06-20') {
            var p2 = document.querySelector('[onclick*="2018 vs 2021"]');
            if (p2) p2.classList.add('active');
        } else if (thenVal === '2020-01-15' && nowVal === '2024-10-21') {
            var p3 = document.querySelector('[onclick*="2020 vs 2024"]');
            if (p3) p3.classList.add('active');
        }

        // 9. Invalidate map viewports to eliminate any tile rendering lag
        if (thenMap) thenMap.invalidateSize({ pan: false });
        if (nowMap)  nowMap.invalidateSize({ pan: false });
    }

    /**
     * Setup Date Inputs with immediate input and change listeners.
     */
    function setupDateInputs() {
        var inputIds = ['then-date', 'now-date', 'range-from', 'range-to'];

        inputIds.forEach(function (id) {
            var el = document.getElementById(id);
            if (!el) return;

            // Remove any legacy listener if already bound
            if (el._geoclixBound) return;
            el._geoclixBound = true;

            function onDateChange() {
                updateDateImagery();
                if (window.GeoClixTimelapse) {
                    GeoClixTimelapse.buildFramesFromDates();
                }
            }

            el.addEventListener('input', onDateChange);
            el.addEventListener('change', onDateChange);
        });
    }

    // Proactively bind date inputs on load so they are ready before user clicks any map
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setupDateInputs);
    } else {
        setupDateInputs();
    }

    /**
     * Cleanup and destroy analysis maps.
     */
    function destroy() {
        _cleanupFns.forEach(function (fn) {
            try { fn(); } catch (_) {}
        });
        _cleanupFns = [];

        stopClouds();
        if (cloudCanvas) {
            try { cloudCanvas.remove(); } catch (_) {}
            cloudCanvas = null;
            cloudCtx = null;
        }

        var scanLine = document.getElementById('transition-scan-line');
        if (scanLine) {
            try { scanLine.remove(); } catch (_) {}
        }

        var hud = document.getElementById('transition-video-hud');
        if (hud) {
            try { hud.remove(); } catch (_) {}
        }

        if (thenMap) {
            try { thenMap.remove(); } catch (_) {}
            thenMap = null;
        }
        if (nowMap) {
            try { nowMap.remove(); } catch (_) {}
            nowMap = null;
        }
    }

    return {
        init: init,
        destroy: destroy,
        updateDateImagery: updateDateImagery,
        updateYear: function (y) { updateDateImagery(); },
        getTileLayerForDate: getTileLayerForDate,
        updateTransitionProgress: updateTransitionProgress,
        getAnalysisMaps: function () { return { thenMap: thenMap, nowMap: nowMap }; }
    };
})();

window.GeoClixAnalysis = GeoClixAnalysis;
