/**
 * GeoClix Configuration
 * Free API keys — no payment required
 * Copy this to config.js and fill in your keys
 */
const GEOCLIX_CONFIG = {
    // OpenWeatherMap — Free tier: 1000 calls/day
    // Get yours at: https://openweathermap.org/api
    OPENWEATHER_API_KEY: '971d4cd027d9859acaf56611b37243f8',

    // NASA FIRMS — Free, unlimited
    // Get yours at: https://firms.modaps.eosdis.nasa.gov/api/area/
    FIRMS_API_KEY: 'PLAK0ae7706bd40e44838f87ef64b71abbd0',

    // Open Elevation API — Free, no key needed
    ELEVATION_API: 'https://api.open-elevation.com/api/v1/lookup',

    // Sentinel Hub — Free trial (30k requests/month)
    // Register at: https://www.sentinel-hub.com/
    SENTINEL_HUB_INSTANCE_ID: '',

    // Map defaults
    DEFAULT_CENTER: [22.5, 82.5],  // Center of India
    DEFAULT_ZOOM: 5,
    MIN_ZOOM: 4,
    MAX_ZOOM: 18,

    // India bounding box
    INDIA_BOUNDS: [[6.5, 68.0], [35.5, 97.5]],

    // Tile servers (all free)
    TILES: {
        satellite: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}',
        terrain: 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',
        dark: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
        topo: 'https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png'
    },

    // Sentinel-2 cloudless mosaic (EOX, free)
    SENTINEL2_TILES: 'https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless-2023_3857/default/g/{z}/{y}/{x}.jpg',

    // Data time range
    DATA_START_YEAR: 2016,
    DATA_END_YEAR: 2026,

    // Update intervals (ms)
    WEATHER_UPDATE_INTERVAL: 300000,  // 5 minutes
    FIRE_UPDATE_INTERVAL: 3600000,    // 1 hour

    // Demo mode (uses mock data when API keys are empty)
    get DEMO_MODE() {
        return !this.OPENWEATHER_API_KEY && !this.FIRMS_API_KEY;
    }
};
